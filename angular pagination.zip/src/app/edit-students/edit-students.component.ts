import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-edit-students',
  templateUrl: './edit-students.component.html',
  styleUrls: ['./edit-students.component.css']
})
export class EditStudentsComponent implements OnInit {

  addForm: any;
 HobbyList:any = ["cricket","Movie","TV","reading","Magazine"];
 HobbyArray:any[]=[];
 vals=''  
 data = this.vals.split(',');
  student_id: any;
  constructor(private formBuilder : FormBuilder,
     private router : Router,
     private studentservice : StudentsService,
     private url : ActivatedRoute
     ) 
     { 
      this.addForm = this.formBuilder.group({
        id:[],
        first_name: ['',Validators.required],
        last_name: ['',Validators.required],
        email: ['',Validators.required],
        password: ['',Validators.required],
        gender: ['',Validators.required],
        //hobbyField: new FormControl(this.data),
        country: ['',Validators.required],
      })
     }

  /*get authorizedArray(){
    return this.addForm.get(hobbyField) as FormArray;
  }*/ 
  setAuthorized(data:string[]){
   this.HobbyArray = this.HobbyList.map((x:any)=>({
    name: x,
    value: data.indexOf(x) >= 0
   }) );
  } 
  parse(){
    const result = this.HobbyList.map(
      (x:any,index:any)=>(this.HobbyArray[index].value ? x : null)
    ).filter((x:any) => x);
    return result.length>0?result:null
  }
  editStudent(){

  }
  ngOnInit(): void {
  this.student_id = this.url.snapshot.params['id']
  if(this.student_id>0){
    this.studentservice.getSingleStudent(this.student_id).subscribe((
      (data:any)=>{
        this.addForm.patchValue(data);
      }
    ))
  }
  //console.log(this.student_id);  
  this.setAuthorized(this.data)  

  }
  onEdit(){
   this.studentservice.editStudent(this.addForm.value).subscribe(
   (data:any)=> {
     this.router.navigate(['/']);
   }
   ,
   error=> {
    alert(error);
   }
   )
  }

}
