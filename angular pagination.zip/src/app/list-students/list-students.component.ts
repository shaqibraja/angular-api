import { Component, OnInit } from '@angular/core';
import { StudentsService } from '../students.service';

@Component({
  selector: 'app-list-students',
  templateUrl: './list-students.component.html',
  styleUrls: ['./list-students.component.css']
})
export class ListStudentsComponent implements OnInit {
  students: any;
  page:any=1;
  limit:any=5;
  skip:any;
  totalCount:any;
  constructor(private studentservice : StudentsService) { }

  ngOnInit(): void {
    this.getEmployeeData();
	/*
	this.studentservice.getStudent().subscribe(

      (data:any)=>{
        this.students = data;
      }
    )*/
  }
   
  getEmployeeData(){
	  if(this.page==1){
		  this.skip=0;
	  }else{
		  this.skip = (this.page-1) * this.limit;
	  }
	  var requestObj = {
		  'limit':this.limit,
		  'skip':this.skip
	  }
	  console.log(requestObj);
	  this.studentservice.getStudent(requestObj).subscribe(

      (data:any)=>{
       // console.log(data);
        this.students = data.data;
		this.totalCount=data.totalRecord;
      }
    ) 
  }

  deleteStudent(student:any){
    this.studentservice.deleteStudent(student.id).subscribe(data=>{
    this.students = this.students.filter((u: any) => u! == student);
    })
  }

}
