import { Injectable } from '@angular/core';
import { HttpClient ,HttpParams} from '@angular/common/http';
import { Students } from './Students';
@Injectable({
  providedIn: 'root'
})
export class StudentsService {

  constructor(private http:HttpClient) { }

  baseUrl: string = 'http://localhost/apicreate/crudapi/newcrud/';
  basrurllaravel: string='http://127.0.0.1:8000/api/'; 
  getStudent(datas:any){
   //return this.http.post<Students[]>(this.baseUrl+'fetchallrecords_api.php',datas)
   return this.http.post(this.basrurllaravel+'getdatalar' , datas);

  }
  getSingleStudent(id:any){
    return this.http.get<Students[]>(this.baseUrl+'fetchsingle.php?id='+id)
 
   }

  deleteStudent(id:any){
    return this.http.delete(this.baseUrl+'delete_api.php?id=' +id);
 
   }
    createStudent(student:any){
    return this.http.post(this.baseUrl+'create_api_new.php' , student);
 
   }
   editStudent(student:any){
    return this.http.post(this.baseUrl+'update_api_new.php' , student);
 
   }
}
