<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  
  <form class="form-horizontal bucket-form" action="{{route('import-user')}}" method="POST" enctype="multipart/form-data">
                    @csrf
					<div class="form-group">
                        <label class="col-sm-3 control-label">Import Excel</label>
                        <div class="col-sm-6">
                            
                 <input type="file" name="file">
                @error('file')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
						
						<br/><br/>
                        <button type="submit" class="btn btn-primary ml-3">Submit</button>
						<br/><br/>
						<a href="{{route('export-user')}}">Export Excel</a>
                    </div>
					
					
                </form>