<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use DB;
class student extends Model
{
    use HasFactory;
	public $timestamps = false;
	function apiDatalar($skip,$limit){
		$data = DB::table('students')->skip($skip)->take($limit)->get();
		return $data;
	}
	function getTotalStudent(){
		$data = DB::table('students')->get()->count();
		return $data;
	}
	
}
