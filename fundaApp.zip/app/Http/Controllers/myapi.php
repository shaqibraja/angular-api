<?php

namespace App\Http\Controllers;
use App\Exports\UsersExport;
use App\Imports\UsersImport;
use Illuminate\Http\Request;
use App\Models\employee;
use App\Models\student;
use App\Models\course_detail;
use App\Models\student_information;
use App\Models\registration;
use App\Models\notification;
use App\Models\result;
use App\Models\TestPaper;
use App\Models\testaper;
use App\Models\gallary;
use App\Models\slider;
use App\Models\marquee;
use App\Models\home_course;
use App\Models\about;
use App\Models\teacher;
use App\Models\youtube;
use App\Models\studentfee;
use App\Models\paystudent;
use App\Models\prenput;
use App\Models\moreinput;
use Excel;
use DB;
class myapi extends Controller
{
	
    function apiData(){
		return student::all();
		
	}
	function apicourseData(){
		return course_detail::all();
		
	}
	function apiDatalar(Request $request){
		
		$skip = $request->skip;
		$limit = $request->limit;
		$studentModel = new student;
		$data = $studentModel->apiDatalar($skip,$limit);
		$totalCount = $studentModel->getTotalStudent();
        $response["data"] = $data;
		$response["totalRecord"] = $totalCount;
		return response()->json($response); 		
		// return student::all();
		
	}
	
	function apiSingleData($id){
		//echo "$id";exit;
		return student::Find($id);
		
	}
	function apiCourseSingleData($id){
		//echo "$id";exit;
		return course_detail::Find($id);
		
	}
	/*
	function apiData($id=null){
		return $id?employee::Find($id):employee::all();
		
	}
	*/
	function addData(Request $request){
		
		
		/*
		$student = new student;
		$student->first_name = $request->first_name;
		$student->email = $request->first_name;
		print_r($student->first_name);exit;
		$res = $student->save();
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}*/
		$student = new student;
        $folderPath = "upload/";
		$imageName = '';
		$student->first_name = $request->first_name;
		$student->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
      
           $image_type_aux = explode("image/", $image_parts[0]);
      
           $image_type = $image_type_aux[1];
      
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . '.png';
	        file_put_contents($file, $image_base64);	
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		$student->first_name = $request->first_name;
        $student->last_name = $request->last_name;
        $student->email = $request->email;
        $student->password = $request->password;
        $student->gender = $request->gender;
        $student->country = $request->country;
		$student->hobbies = $request->password;
		$student->image = $file;
        
		$res = $student->save();
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}
	}
	
	function updateData(Request $request){
		$student = student::find($request->id);
		
		/*$employee->name = $request->name;
		$employee->email = $request->email;
		*/
		$folderPath = "upload/";
		$imageName = '';
		$student->first_name = $request->first_name;
		$student->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
      
           $image_type_aux = explode("image/", $image_parts[0]);
      
           $image_type = $image_type_aux[1];
      
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . '.png';
	        file_put_contents($file, $image_base64);	
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		$student->first_name = $request->first_name;
        $student->last_name = $request->last_name;
        $student->email = $request->email;
        $student->password = $request->password;
        $student->gender = $request->gender;
        $student->country = $request->country;
		//$student->hobbies = $request->password;
		$student->image = $file;
		//echo "$student->first_name";exit;
		$reslt = $student->save();
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
	}
	
	function deleteData($id){
		$student = student::find($id);
		
		$re = $student->delete();
		if($re){
			return ["status"=>"Data has been deleted"];	
		}else{
			return ["status"=>"Data has not been deleted"];	
		}
	}
	
	public function importUser(Request $request){
	 define('CSV_PATH','C:/xampp/htdocs/apicreate/crudapi/newcrud/');
     $uploadfile = basename($_FILES['fileToUpload']['name']);
     // echo $request->fileToUpload;exit;
	 // print_r($request->fileToUpload);exit;
     
	 $filename =   basename($_FILES['fileToUpload']['name']);
	  // print_r($filename);exit;
	  // dd("Import");
	  // print_r($request->file('file'));exit;
	// Excel::import(new UsersImport, $request->file('file'));
	Excel::import(new UsersImport, $request->fileToUpload);
	// return redirect('excel');	
  }
  
  
  
  
  function addCourseData(Request $request){
		
		// print_r($course_detail->add_date);exit;
		
		$course_detail = new course_detail;
		$course_detail->course_name = $request->course_name;
		$course_detail->duration = $request->duration;
		$course_detail->course_start_date = $request->course_start_date;
		$course_detail->course_completion = $request->course_completion;
		$course_detail->fees = $request->fees;
		$course_detail->student_benefit = $request->student_benefit;
		$course_detail->course_description = $request->course_description;
		$course_detail->add_date = date("Y-m-d");
		
		// print_r($course_detail->add_date);exit;
		$res = $course_detail->save();
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}
		
	}
  
  function updateCourseData(Request $request){
		$course_detail = course_detail::find($request->id);
		
		$course_detail->course_name = $request->course_name;
		$course_detail->duration = $request->duration;
		$course_detail->course_start_date = $request->course_start_date;
		$course_detail->course_completion = $request->course_completion;
		$course_detail->fees = $request->fees;
		$course_detail->student_benefit = $request->student_benefit;
		$course_detail->course_description = $request->course_description;
		
		$reslt = $course_detail->save();
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
      }
	  
	  
	  function addStudentData(Request $request){
		
		$student_information = new student_information;
        
		$student_information->name = $request->name;
		$student_information->phone = $request->phone;
        $student_information->email = $request->email;
        $student_information->message = $request->message;
        $student_information->add_date = date("Y-m-d");
        
		$res = $student_information->save();
		if($res){
		 return ["status"=>"Your Enquiry Has Been Submitted, Will Contact You Soon."];	
		}else{
			return ["status"=>"Some Issue Has Generated PLease Try Agian"];
		}
	}
	
	function apiProfileData($id){
		//return "$id";studentfee
		// return registration::where('email','=',$id) ->get();
		
		return $data = result::join("registrations", function ($join) {
            $join->on("results.student_id", "=", "registrations.id");
        })->where('registrations.email','=',$id)->limit(3)->orderBy('results.id', 'desc') ->get();
		
		// return testaper::orderBy('id', 'DESC')->get();;
	}
	
	
	function registrationData(Request $request){
		$registration = registration::where('email','=',$request->email) ->get();
		if(!empty($registration['0']->email)){
		if($registration['0']->email==$request->email){
			return ["status"=>"This Email Already Exist."];
		}
		else{
		
		$registration = new registration;
        
		$registration->name = $request->username;
		$registration->email = $request->email;
        $registration->password = $request->password;
        $registration->add_date = date("Y-m-d");
        // echo $registration->password;exit;
		$res = $registration->save();
		if($res){
		 return ["status"=>"You Have Successfully Registered , Go To Login Page To Enter In Your Account."];	
		}else{
			return ["status"=>"Some Issue Has Generated PLease Try Agian"];
		}
	  }
		}else{
			$registration = new registration;
        
		$registration->name = $request->username;
		$registration->email = $request->email;
        $registration->password = $request->password;
        $registration->add_date = date("Y-m-d");
        // echo $registration->password;exit;
		$res = $registration->save();
		if($res){
		 return ["status"=>"You Have Successfully Registered , Go To Login Page To Enter In Your Account."];	
		}else{
			return ["status"=>"Some Issue Has Generated PLease Try Agian"];
		}
		}
	}
	
	
	function changePassword(Request $request){
		
		$reslt = DB::update('update registrations set password = ? where email = ?',[$request->password,$request->email]);
		
		if($reslt){
		    return ["status"=>"Password Successfully Changed"];	
		}else{
			return ["status"=>"Something Went Wrong , Please Try Again"];
		}
      }
	  
	  function studentInformationData(){
		return student_information::all();
		
	}
	
	
	function importNotification(Request $request){
		
		
		
		$notification = new notification;
        $folderPath = "upload/";
		$imageName = '';
		$notification->first_name = $request->first_name;
		$notification->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
       // print_r($request->file);exit;
           $image_type_aux = explode("image/", $image_parts[0]);
		   $image_type_aux = explode(".",$request->file);
		   $image_type_aux = $image_type_aux[1];
		   //$image_type_aux = explode("/",$image_type_aux[0]);
		   // print_r($image_type_aux);exit;
           
           $image_type = $image_type_aux[1];
           
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . ".$image_type_aux";
		   
	        file_put_contents($file, $image_base64);	
			
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		$notification->first_name = $request->first_name;
		$notification->image = $file;
		$notification->add_date = date("Y-m-d");
        
		$res = $notification->save();
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}
	}
	
	function apigetNotification(){
		return notification::orderBy('id', 'DESC')->get();;
		
	}
	function deleteNotification($id){
		$student = notification::find($id);
		
		$re = $student->delete();
		if($re){
			return ["status"=>"Data has been deleted"];	
		}else{
			return ["status"=>"Data has not been deleted"];	
		}
	}
	
	
	function importResult(Request $request){
		
		
		
		$result = new result;
        $folderPath = "upload/";
		$imageName = '';
		$result->student_id = $request->student_id;
		$result->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
       // print_r($request->file);exit;
           $image_type_aux = explode("image/", $image_parts[0]);
		   $image_type_aux = explode(".",$request->file);
		   $image_type_aux = $image_type_aux[1];
		   //$image_type_aux = explode("/",$image_type_aux[0]);
		   // print_r($image_type_aux);exit;
           
           $image_type = $image_type_aux[1];
           
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . ".$image_type_aux";
		   
	        file_put_contents($file, $image_base64);	
			
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		$result->student_id = $request->student_id;
		$result->test_name = $request->test_name;
		$result->marks = $request->marks;
		$result->fee_details = $request->fee_details;
		$result->image = $file;
		$result->add_date = date("Y-m-d");
        
		$res = $result->save();
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}
	}
	
	function apigetResult(){
		//return result::orderBy('id', 'DESC')->get();;registration
		return $data = result::join("registrations", function ($join) {
            $join->on("results.student_id", "=", "registrations.id");
        })->get();
		
	}
	function deleteResult($id){
		$result = result::find($id);
		
		$re = $result->delete();
		if($re){
			return ["status"=>"Data has been deleted"];	
		}else{
			return ["status"=>"Data has not been deleted"];	
		}
	}
	
	function importTestPaper(Request $request){
		
		
		
		$testaper = new testaper;
        $folderPath = "upload/";
		$imageName = '';
		$testaper->first_name = $request->first_name;
		$testaper->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
       // print_r($request->file);exit;
           $image_type_aux = explode("image/", $image_parts[0]);
		   $image_type_aux = explode(".",$request->file);
		   $image_type_aux = $image_type_aux[1];
		   //$image_type_aux = explode("/",$image_type_aux[0]);
		   // print_r($image_type_aux);exit;
           
           $image_type = $image_type_aux[1];
           
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . ".$image_type_aux";
		   
	        file_put_contents($file, $image_base64);	
			
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		$testaper->first_name = $request->first_name;
		$testaper->image = $file;
		$testaper->add_date = date("Y-m-d");
        
		$res = $testaper->save();
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}
	}
	
	function deleteTestPaper($id){
		$result = testaper::find($id);
		
		$re = $result->delete();
		if($re){
			return ["status"=>"Data has been deleted"];	
		}else{
			return ["status"=>"Data has not been deleted"];	
		}
	}
	function apiTestPaper(){
		return testaper::orderBy('id', 'DESC')->get();;
		
	}
	
	function saveGallarydata(Request $request){
		
		$gallary = new gallary;
        $folderPath = "upload/";
		$imageName = '';
		$gallary->first_name = $request->first_name;
		$gallary->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
      
           $image_type_aux = explode("image/", $image_parts[0]);
      
           $image_type = $image_type_aux[1];
      
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . '.png';
	        file_put_contents($file, $image_base64);	
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		$gallary->first_name = $request->first_name;
		$gallary->image = $file;
        $gallary->add_date = date("Y-m-d");
		
		$res = $gallary->save();
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}
	}
	
	function apigetGallary(){
		return gallary::orderBy('id', 'DESC')->get();;
		
	}
	function deleteGallary($id){
		$result = gallary::find($id);
		
		$re = $result->delete();
		if($re){
			return ["status"=>"Data has been deleted"];	
		}else{
			return ["status"=>"Data has not been deleted"];	
		}
	}
	
	function getSliderData(){
		return slider::orderBy('id', 'DESC')->get();;
		
	}
	
	function getSliderdatas($id){
		//echo "$id";exit;
		return slider::Find($id);
		
	}
	
	
	function updateSliderdata(Request $request){
		$slider = slider::find($request->id);
		
		/*$employee->name = $request->name;
		$employee->email = $request->email;
		*/
		$folderPath = "upload/";
		$imageName = '';
		// $slider->title = $request->title;
		// $slider->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
      
           $image_type_aux = explode("image/", $image_parts[0]);
      
           $image_type = $image_type_aux[1];
      
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . '.png';
	        file_put_contents($file, $image_base64);	
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		if(!empty($file)){
		  $slider->slider_title = $request->slider_title;
		  $slider->image = $file;
		 //echo "yes";
		 //echo $slider->image;exit;
		$reslt = $slider->save();	
		}else{
			$slider->slider_title = $request->slider_title;
		    //echo "No";
			//echo $slider->image;exit;
		    $reslt = $slider->save();
		}
		
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
	}
	
	function getMarqueeData(){
		return marquee::all();
		
	}
	function gethomeCourseData(){
		return home_course::all();
		
	}
	function getaboutData(){
		return about::all();
		
	}
	function getteacherData(){
		return teacher::all();
		
	}
	function getyoutubeData(){
		return youtube::all();
		
	}
	
	function apiStudentfeeData($id){
		// return "$id";exit;//studentfee
		// return registration::where('email','=',$id) ->get();
		
		return $data = paystudent::join("registrations", function ($join) {
            $join->on("paystudents.student_id", "=", "registrations.id");
        })->where('registrations.email','=',$id)->limit(3)->orderBy('paystudents.id', 'desc') ->get();
		
		// return testaper::orderBy('id', 'DESC')->get();;
	}
	function getSingleHomeCourse($id){
		//echo "$id";exit;
		return home_course::Find($id);
		
	}
	
	function editHomeCourse(Request $request){
		// echo "Test";exit;
		$home_course = home_course::find($request->id);
		
		/*$employee->name = $request->name;
		$employee->email = $request->email;
		*/
		$folderPath = "upload/";
		$imageName = '';
		// $slider->title = $request->title;
		// $slider->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
      
           $image_type_aux = explode("image/", $image_parts[0]);
      
           $image_type = $image_type_aux[1];
      
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . '.png';
	        file_put_contents($file, $image_base64);	
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		if(!empty($file)){
		  $home_course->course_name = $request->course_name;
		  $home_course->description = $request->description;
		  $home_course->image = $file;
		 //echo "yes";
		 //echo $slider->image;exit;
		$reslt = $home_course->save();	
		}else{
			$home_course->course_name = $request->course_name;
			$home_course->description = $request->description;
		    //echo "No";
			//echo $slider->image;exit;
		    $reslt = $home_course->save();
		}
		
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
	}
	
	function getSingleslidNot($id){
		//echo "$id";exit;
		return marquee::Find($id);
		
	}
	
	function editslideNot(Request $request){
		// echo "Test";exit;
		$marquee = marquee::find($request->id);
		$marquee->title = $request->title;
		$reslt = $marquee->save();	
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
	}
	
	function getSingleTeacher($id){
		//echo "$id";exit;
		return teacher::Find($id);
		
	}
	function editTeacher(Request $request){
		// echo "Test";exit;
		$teacher = teacher::find($request->id);
		
		/*$employee->name = $request->name;
		$employee->email = $request->email;
		*/
		$folderPath = "upload/";
		$imageName = '';
		// $slider->title = $request->title;
		// $slider->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
      
           $image_type_aux = explode("image/", $image_parts[0]);
      
           $image_type = $image_type_aux[1];
      
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . '.png';
	        file_put_contents($file, $image_base64);	
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		if(!empty($file)){
		  $teacher->name = $request->name;
		  $teacher->title = $request->title;
		  $teacher->description = $request->description;
		  $teacher->image = $file;
		 //echo "yes";
		 //echo $slider->image;exit;
		$reslt = $teacher->save();	
		}else{
			$teacher->name = $request->name;
		    $teacher->title = $request->title;
			$teacher->description = $request->description;
		    //echo "No";
			//echo $slider->image;exit;
		    $reslt = $teacher->save();
		}
		
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
	}
	
	function getSingleYoutube($id){
		//echo "$id";exit;
		return youtube::Find($id);
		
	}
	function editYoutube(Request $request){
		// echo "Test";exit;
		$youtube = youtube::find($request->id);
		$youtube->title = $request->title;
		$youtube->youtube_link = $request->youtube_link;
		$reslt = $youtube->save();	
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
	}
	function getSingleAbout($id){
		//echo "$id";exit;
		return about::Find($id);
		
	}
	function editAbout(Request $request){
		// echo "Test";exit;
		$about = about::find($request->id);
		
		/*$employee->name = $request->name;
		$employee->email = $request->email;
		*/
		$folderPath = "upload/";
		$imageName = '';
		// $slider->title = $request->title;
		// $slider->image = $request->file;
		
	   if($request->file){
		  $image_parts = explode(";base64,", $request['fileSource']);
      
           $image_type_aux = explode("image/", $image_parts[0]);
      
           $image_type = $image_type_aux[1];
      
           $image_base64 = base64_decode($image_parts[1]);
      
           $file = $folderPath . uniqid() . '.png';
	        file_put_contents($file, $image_base64);	
			//$file->move($folderPath,$file); 
			//$request->image->move(public_path('upload'),$file);
	     
		}
		if(!empty($file)){
		  $about->title = $request->title;
		  $about->description = $request->description;
		  $about->about_image = $file;
		 //echo "yes";
		 //echo $slider->image;exit;
		$reslt = $about->save();	
		}else{
			$about->title = $request->title;
			$about->description = $request->description;
		    //echo "No";
			//echo $slider->image;exit;
		    $reslt = $about->save();
		}
		
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
	}
	function createFee(Request $request){
		
		$paystudent = new paystudent;
        $paystudent->student_id = $request->student_id;
		$paystudent->fee_details = $request->fee_details;
		$paystudent->add_date = date("Y-m-d");
        
		$res = $paystudent->save();
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}
	}
	function getfee(){
		//return result::orderBy('id', 'DESC')->get();;registration
		return $categoryProducts = paystudent::join('registrations', 'registrations.id', '=', 'paystudents.student_id')
        ->select('paystudents.*', 'registrations.name')->orderBy('paystudents.id', 'desc')
        ->get();
		/*return $data = paystudent::join("registrations", function ($join) {
            $join->on("registrations.name,paystudents.fee_details,paystudents.add_date,paystudents.id, paystudents.student_id", "=", "registrations.id");
        })->get();*/
		// 'name','fee_details','add_date','id'->orderBy('paystudents.id', 'desc') ->get()
	}
	function deletefee($id){
		$paystudent = paystudent::find($id);
		
		$re = $paystudent->delete();
		if($re){
			return ["status"=>"Data has been deleted"];	
		}else{
			return ["status"=>"Data has not been deleted"];	
		}
	}
	
	function addMorePre(Request $request){
		//print_r($request->quantities);exit;
		$prenput = new prenput;
        $prenput->name = $request->name;
		$prenput->qtya = $request->qtya;
		$prenput->pricea = $request->pricea;
		$prenput->add_date = date("Y-m-d");
        
		$res = $prenput->save();
		$inseetedid = $prenput->id;
		foreach($request->quantities as $test){
			
			// print_r($test['qty']);exit;
			$moreinput = new moreinput;
            $moreinput->input_id = $inseetedid;
            $moreinput->qty = $test['qty'];
		    $moreinput->price = $test['price'];
		    $moreinput->add_date = date("Y-m-d");
        
		$res = $moreinput->save();
			
		}
		
		if($res){
		 return ["status"=>"Data has been saved"];	
		}else{
			return ["status"=>"Data has not been saved"];
		}
	}
	function getAddmore(){
		
		return prenput::all();
		
	}
	function getaddMorePre($id){
		
		$data = prenput::Find($id);
		$data['products'] = moreinput::where('input_id', $id)->get();
		return $data;
		
	}
	
	function editddMorePre(Request $request){
		// print_r($request->quantities);exit;
		  $prenput = prenput::find($request->id);
		  $prenput->name = $request->name;
		  $prenput->qtya = $request->qtya;
		  $prenput->pricea = $request->pricea;
		  
		  $reslt = $prenput->save();	
		  
		  $resultmoreinput = moreinput::where('input_id',$request->id);
		  $re = $resultmoreinput->delete();
		
		foreach($request->quantities as $tests){
			
			// print_r($request->id);exit;
			$moreinput = new moreinput;
            $moreinput->input_id = $request->id;
            $moreinput->qty = $tests['qty'];
		    $moreinput->price = $tests['price'];
		    $moreinput->add_date = date("Y-m-d");
            $res = $moreinput->save();
			
		}
		// print_r($request->id);exit;
		if($reslt){
		    return ["status"=>"Data has been updated"];	
		}else{
			return ["status"=>"Data has not been updated"];
		}
	}
	
}
