<?php

namespace App\Http\Controllers;
use App\Exports\UsersExport;
use App\Imports\UsersImport;
use Illuminate\Http\Request;
use Excel;


class UserController extends Controller
{
    public function exportUser(){
	  
	  //dd("Export");
	  return Excel::download(new UsersExport,'user.xlsx');
  }
  //public function importUser(Request $request){
	  // print_r($request->file('file'));exit;
	  // dd("Import");
	  // print_r($request->file('file'));exit;
	//Excel::import(new UsersImport, $request->file('file'));
	// return redirect('excel');	
  //}
  public function importUser(Request $request){
	 define('CSV_PATH','C:/xampp/htdocs/apicreate/crudapi/newcrud/');
     $uploadfile = basename($_FILES['fileToUpload']['name']);
     // echo $request->fileToUpload;exit;
	 // print_r($request->fileToUpload);exit;
     
	 $filename =   basename($_FILES['fileToUpload']['name']);
	  // print_r($filename);exit;
	  // dd("Import");
	  // print_r($request->file('file'));exit;
	// Excel::import(new UsersImport, $request->file('file'));
	Excel::import(new UsersImport, $request->fileToUpload);
	// return redirect('excel');	
  }
}
