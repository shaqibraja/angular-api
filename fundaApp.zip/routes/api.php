<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\myapi;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('getdatalar',[myapi::class,'apiDatalar']);
Route::get('getdata',[myapi::class,'apiData']);
Route::get('getdatas/{id}',[myapi::class,'apiSingleData']);
/*
Route::get('getdatas/{id?}',[myapi::class,'apiData']);
*/
Route::post('savedata',[myapi::class,'addData']);
Route::post('updatedata',[myapi::class,'updateData']);
Route::get('delete/{id}',[myapi::class,'deleteData']);

Route::post('import-user',[UserController::class,'importUser'])->name('import-user');

Route::post('save-course-detail',[myapi::class,'addCourseData']);
Route::get('getcoursedata',[myapi::class,'apicourseData']);
Route::get('getcoursedatas/{id}',[myapi::class,'apiCourseSingleData']);
Route::post('updateCoursedata',[myapi::class,'updateCourseData']);

Route::post('savestudentdata',[myapi::class,'addStudentData']);
Route::get('getProfiledata/{id}',[myapi::class,'apiProfileData']);
Route::post('saveregistrationtdata',[myapi::class,'registrationData']);

Route::post('changePassword',[myapi::class,'changePassword']);
Route::get('studentInformationData',[myapi::class,'studentInformationData']);
Route::post('importNotification',[myapi::class,'importNotification'])->name('importNotification');
Route::get('getNotification',[myapi::class,'apigetNotification']);
Route::get('deleteNotification/{id}',[myapi::class,'deleteNotification']);
Route::post('importResult',[myapi::class,'importResult'])->name('importResult');

Route::get('apigetResult',[myapi::class,'apigetResult']);
Route::get('deleteResult/{id}',[myapi::class,'deleteResult']);
Route::post('importTestPaper',[myapi::class,'importTestPaper'])->name('importTestPaper');
Route::get('deleteTestPaper/{id}',[myapi::class,'deleteTestPaper']);
Route::get('apiTestPaper',[myapi::class,'apiTestPaper']);
Route::post('saveGallarydata',[myapi::class,'saveGallarydata']);
Route::get('apigetGallary',[myapi::class,'apigetGallary']);
Route::get('deleteGallary/{id}',[myapi::class,'deleteGallary']);

Route::get('getSliderData',[myapi::class,'getSliderData']);
Route::get('getSliderdatas/{id}',[myapi::class,'getSliderdatas']);
Route::post('updateSliderdata',[myapi::class,'updateSliderdata']);
// Route::get('getNotificationData',[myapi::class,'getNotificationData']);

Route::get('getMarqueeData',[myapi::class,'getMarqueeData']);
Route::get('gethomeCourseData',[myapi::class,'gethomeCourseData']);
Route::get('getaboutData',[myapi::class,'getaboutData']);
Route::get('getteacherData',[myapi::class,'getteacherData']);
Route::get('getyoutubeData',[myapi::class,'getyoutubeData']);

Route::get('apiStudentfeeData/{id}',[myapi::class,'apiStudentfeeData']);
Route::get('getSingleHomeCourse/{id}',[myapi::class,'getSingleHomeCourse']);
Route::post('editHomeCourse',[myapi::class,'editHomeCourse']);
Route::get('getSingleslidNot/{id}',[myapi::class,'getSingleslidNot']);
Route::post('editslideNot',[myapi::class,'editslideNot']);
Route::get('getSingleTeacher/{id}',[myapi::class,'getSingleTeacher']);
Route::post('editTeacher',[myapi::class,'editTeacher']);
Route::get('getSingleYoutube/{id}',[myapi::class,'getSingleYoutube']);
Route::post('editYoutube',[myapi::class,'editYoutube']);
Route::get('getSingleAbout/{id}',[myapi::class,'getSingleAbout']);
Route::post('editAbout',[myapi::class,'editAbout']);
Route::post('createFee',[myapi::class,'createFee'])->name('createFee');
Route::get('getfee',[myapi::class,'getfee']);
Route::get('deletefee/{id}',[myapi::class,'deletefee']);

Route::post('addMorePre',[myapi::class,'addMorePre'])->name('addMorePre');
Route::get('getAddmore',[myapi::class,'getAddmore']);
Route::get('getaddMorePre/{id}',[myapi::class,'getaddMorePre']);
Route::post('editddMorePre',[myapi::class,'editddMorePre']);

// Route::get('getAddmore/{id}',[myapi::class,'apiStudentfeeData']);