<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
  
  <form class="form-horizontal bucket-form" action="<?php echo e(route('import-user')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
					<div class="form-group">
                        <label class="col-sm-3 control-label">Import Excel</label>
                        <div class="col-sm-6">
                            
                 <input type="file" name="file">
                <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
						
						<br/><br/>
                        <button type="submit" class="btn btn-primary ml-3">Submit</button>
						<br/><br/>
						<a href="<?php echo e(route('export-user')); ?>">Export Excel</a>
                    </div>
					
					
                </form><?php /**PATH C:\xampp\htdocs\API-Test\fundaApp\resources\views/excel.blade.php ENDPATH**/ ?>